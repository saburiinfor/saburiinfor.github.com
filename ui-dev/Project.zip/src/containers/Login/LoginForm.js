import React from "react";

import { Row, Col, Form, Button } from "reactstrap";

import Aux from "../../hoc/Auxwrap";

import InputField from "../../components/Common/InputField/InputField";

 

class LoginForm extends React.Component {

  constructor(props) {

    super(props);

    this.state = {

      identifier: "",

      password: "",

      errors: {},

      isLoading: false

    };

 

    this.onSubmit = this.onSubmit.bind(this);

    this.onChange = this.onChange.bind(this);

  }

 

  onSubmit(e) {

    e.preventDefault();

  }

 

  onChange(e) {

    e.preventDefault();

  }

 

  render() {

    const { errors, identifier, password, isLoading } = this.state;

 

    return (

      <Aux>

        <h1>Login</h1>

        <Form className="form">

          <Row>

            <Col>

              <InputField

                field="identifier"

                label="Username"

                id="userName"

                placeholder="Enter User Name"

              />

            </Col>

          </Row>

          <Row>

            <Col>

              <InputField

                field="password"

                label="Password"

                id="passWord"

               placeholder="Enter Password"

                type="password"

              />

            </Col>

          </Row>

          <Row>

            <Button color="primary" block>

              Submit

            </Button>

          </Row>

        </Form>

      </Aux>

    );

  }

}

 

export default LoginForm;

 
