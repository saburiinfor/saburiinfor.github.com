import React from "react";

import { Container, Row, Col } from "reactstrap";

 

import Aux from "../../hoc/Auxwrap";

import Header from ".././Header/Header";

import Carousel from "../../containers/Carousel/Carousel";

import LoginForm from "../../containers/Login/LoginForm";

import AppointmentRowGroup from "../../containers/Appointment/AppointmentRowGroup";

import ImgWithOverlayTextGroup from "../../containers/ImgWithOverlayText/ImgWithOverlayTextGroup";

import Footer from ".././Footer/Footer";

import "./Layout.module.css";

 

const Layout = props => (

  <Aux>

    <main>

      <Container className="mt-5">

        <div className="TopContainer">

          <Header />

        </div>

        <Row className="MiddleContainer">

          <Col md="6">

            <Carousel />

          </Col>

          <Col md="6">

            <LoginForm />

          </Col>

        </Row>

        <Row>

          <Col>

            <ul>

              <li>Coffee</li>

              <li>Tea</li>

              <li>Milk</li>

            </ul>

          </Col>

        </Row>

        <h1>Screen 2</h1>

        <Row>

          <Col md="8">

            <AppointmentRowGroup />

          </Col>

 

          <Col md="4">

            <ImgWithOverlayTextGroup />

          </Col>

        </Row>

 

        <Footer />

      </Container>

    </main>

  </Aux>

);

export default Layout;
