import React from "react";

import { Row, Col } from "reactstrap";

import SwasthLogo from "../../assets/images/SwasthLogo.png";

import InputField from "../Common/InputField/InputField";

import "./Header.module.css";

 

const Header = props => {

  return (

    <Row>

      <Col md="6">

        <img src={SwasthLogo} alt="Swasth"></img>

        <h2>ConferKare</h2>

      </Col>

      <Col md="6">

        <InputField

          field="search"

          id="passWord"

          placeholder="Please enter the words to serach"

          type="search"

        />

      </Col>

    </Row>

  );

};

 

export default Header;

