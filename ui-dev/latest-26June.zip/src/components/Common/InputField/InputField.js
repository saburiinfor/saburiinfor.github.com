import React from "react";

import { FormGroup, Label, Input } from "reactstrap";

import styles from "./InputField.module.css";

 

const InputField = ({ type, field, label, id, placeholder }) => {

  return (

    <FormGroup>

      <Label for={id}>{label}</Label>

      <Input type={type} name={field} id={id} placeholder={placeholder} />

    </FormGroup>

  );

};

 

InputField.defaultProps = {

  type: "text"

};

 

export default InputField;

