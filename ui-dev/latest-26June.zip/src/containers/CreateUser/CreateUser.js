import React, { Component } from "react";

import {

  Col,

    Row,

  Button,

  Form,

  FormGroup,

  Label,

  Input,

  FormText,

  CustomInput

} from "reactstrap";

import styles from "./CreateUser.module.css";

 

class CreateUser extends Component {

  constructor(props) {

   

    super(props);

    this.state ={

        userTypeId:"1",

        uhid:"P201901",

        name : "" ,

        email : "",

        password : "",

        contactNo : "",

        gender : "F",

        city : "",

        address : "",

        marketId : "",

        appId : "",

        createdBy :"",

        roleid : "",

        bloodgrp: "",

        dob : "",

        status :"" 

 

    }

 

   

  }

  onSubmitHandler = e => {

      console.log("current state is = "+JSON.stringify(this.state));

  }   

  onChangeHandler = e => {

    this.setState({ [e.target.name]: e.target.value });

  };

  render() {

     

    return (

      <Form>

       

        <FormGroup className={styles.floatingLabel}>

         

            <Input

              type="text"

              name="name"

              id="name"            

              className="no-border"

              value={this.state.name}

              onChange={this.onChangeHandler}

            />

        <label>Name</label>

         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>

         

            <Input

              type="email"

              name="email"

              id="email"

              className="no-border"             

              value={this.state.email}

              onChange={this.onChangeHandler}

            />

        <label>Email</label>

         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>

         

            <Input

              type="password"

              name="password"

              id="password"             

              className="no-border"

              value={this.state.password}

              onChange={this.onChangeHandler}

            />

          <label>Password</label>

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>

          <Input

            type="number"

            name="contactNo"

            id="contactNo"           

            className="no-border"

            value={this.state.contactno}

            onChange={this.onChangeHandler}

          />

        <label>Contact Number</label>

        </FormGroup>

 

        <FormGroup>

        <Row className={styles.gender}>

          <Col sm={2}>Gender</Col>

          <Col sm={10}>

            <CustomInput

              inline             

              type="radio"

              id="female"

              name="gender"

              label="Female"

        value="F"

        checked={this.state.gender === 'F'}

                      onChange={this.onChangeHandler}

            />

            <CustomInput

              inline

              type="radio"

              id="male"

              name="gender"

              label="Male"

                value="M"

        checked={this.state.gender === 'M'}

                      onChange={this.onChangeHandler}

            />

          </Col>

        </Row>

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>

          

            <Input

              type="text"

              name="city"

              id="city"             

              className="no-border"

              value={this.state.city}

              onChange={this.onChangeHandler}

             

            />

        <label>City</label>

         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>

         

            <Input

              type="text"

              name="address"

              id="address"            

              className="no-border"

             value={this.state.address}

              onChange={this.onChangeHandler}    

            />

        <label>Address</label>

         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="marketId"

              id="marketId"             

              className="no-border"

              value={this.state.marketId}

              onChange={this.onChangeHandler}

            />         

        <label>Market Id</label>

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="appId"

              id="appId"            

              className="no-border"

              value={this.state.appId}

              onChange={this.onChangeHandler}

            />         

        <label>App Id</label>

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="createdBy"

              id="createdBy"            

              className="no-border"

              value={this.state.createdBy}

              onChange={this.onChangeHandler}

            />

        <label>Created By</label>         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="roleId"

              id="roleId"            

              className="no-border"

              value={this.state.roleId}

              onChange={this.onChangeHandler}

            />

        <label>Role Id</label>         

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="bloodgrp"

              id="bloodgrp"             

              className="no-border"

              value={this.state.bloodgrp}

              onChange={this.onChangeHandler}

            />

        <label>Blood Group</label>         

        </FormGroup>

        <FormGroup>         

            <Input

              type="date"

              name="dob"

              id="dob"            

              className="no-border pl-0"

              value={this.state.dob}

              onChange={this.onChangeHandler}

            />

      

        </FormGroup>

        <FormGroup className={styles.floatingLabel}>         

            <Input

              type="text"

              name="status"

              id="status"             

              className="no-border"

              value={this.state.status}

              onChange={this.onChangeHandler}

            />

        <label>Status</label>         

        </FormGroup>

        <Button color="primary" onClick={this.onSubmitHandler}>Submit</Button>

 

        <Button color="secondary" className="ml-2">

          Cancel

        </Button>

      </Form>

    );

  }

}

 

export default CreateUser;

 

 

