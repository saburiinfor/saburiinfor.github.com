import React from "react";

import { Container, Row, Col } from "reactstrap";

 

import Aux from "../../hoc/Auxwrap";

import Header from ".././Header/Header";

import Carousel from "../../containers/Carousel/Carousel";

import LoginForm from "../../containers/Login/LoginForm";

import CreateUser from  "../../containers/CreateUser/CreateUser";

import Appointments from "../../containers/Appointment/Appointments";

import NewApointment from  "../../containers/NewApointment/NewApointment";

import SelectAppointmentDate from  

"../../containers/SelectAppointmentDate/SelectAppointmentDate";

import Footer from ".././Footer/Footer";

import "./Layout.module.css";

 

const Layout = props => (

  <Aux>

    <main>

      <Container className="mt-5">

       

 



   

    

    

    <div className="TopContainer">

          <Header />

        </div>

        <Row className="MiddleContainer">

          <Col md="6">

            <Carousel />

          </Col>

          <Col md="6">

            <LoginForm />

            <CreateUser />

          </Col>

        </Row>

        <Row>

          <Col>

            <ul>

              <li>Coffee</li>

              <li>Tea</li>

              <li>Milk</li>

            </ul>

          </Col>

        </Row>

        <h1>Appointments Main Screen </h1><hr />

        <Appointments />

    <h1>New Apointment screen</h1><hr />

    <NewApointment />

 

        <Footer />

    <SelectAppointmentDate />

      </Container>

    </main>

  </Aux>

);

export default Layout;

