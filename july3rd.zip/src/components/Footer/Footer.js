import React from "react";

import { Row, Col, Nav, NavLink } from "reactstrap";

import "./Footer.module.css";

 

const Footer = props => {

  return (

    <div className="bottomContainer">

        <Row>

          <Col>

            <Nav className="justify-content-center">

              <NavLink href="#">Privacy</NavLink>

              <NavLink href="#">Security</NavLink>

              <NavLink href="#">Terms of Use</NavLink>

              <NavLink href="#">Sitemap</NavLink>

            </Nav>

          </Col>

        </Row>

        <Row className="bottomContainer">

          <Col>@2019 ConferKare</Col>

        </Row>

      </div>

  );

};

 

export default Footer;
