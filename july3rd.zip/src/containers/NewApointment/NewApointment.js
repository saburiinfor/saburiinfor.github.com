import React, { Component } from "react";

import { Row, Col } from "reactstrap";

import MediaElementGroup from "../../components/Common/Media/MediaElementGroup";

import ImgWithOverlayTextGroup from "../ImgWithOverlayText/ImgWithOverlayTextGroup";

 

import styles from "./NewApointment.module.css";

import classnames from "classnames";

class NewApointment extends Component {

  render() {

    return (

      <Row>

        <Col md="8">

          <div>

            <h1>New appointment</h1>

            <ul className={classnames(styles.customBreadcrump, "p-0")}>

              <li className={styles.active}>Step 1</li>

              <li>Step 2</li>

              <li>Step 3</li>

              <li>Step 4</li>

              <li>Step 5</li>

              <li>Step 6</li>

            </ul>

          </div>

          <MediaElementGroup />

        </Col>

 

        <Col md="4">

          <ImgWithOverlayTextGroup />

        </Col>

      </Row>

    );

  }

}

 

export default NewApointment;
