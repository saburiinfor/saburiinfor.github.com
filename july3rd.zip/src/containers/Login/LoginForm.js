import React from "react";

import { Row, Col, Form, Button } from "reactstrap";

import Aux from "../../hoc/Auxwrap";

import InputField from "../../components/Common/InputField/InputField";

 

class LoginForm extends React.Component {

  constructor(props) {

    super(props);

    this.state = {

        Username:""

   };

 

    this.onSubmit = this.onSubmit.bind(this);

    this.onChange = this.onChange.bind(this);

  }

 

  onSubmit(e) {

    e.preventDefault();

  }

 

  onChange(e) {   

    e.preventDefault();

    this.setState({[e.target.name]: e.target.value })

  }

 

  render() {

   // const { } = this.state;   

    return (

      <Aux>

        <h1>Login</h1>

        <Form className="form">

          <Row>

            <Col>

              <InputField

                name="userName"

                label="Username"

                id="userName"

                placeholder="Enter User Name"

                value={this.state.userName}

                onChange={this.onChange}

              />

            </Col>

          </Row>

          <Row>

            <Col>

              <InputField

                name="password"

                label="Password"

                id="passWord"

                placeholder="Enter Password"

                type="password"

                value={this.state.password}

                onChange={this.onChange}

              />

            </Col>

          </Row>

          <Row>

            <Button color="primary" block>

              Submit

            </Button>

          </Row>

        </Form>

      </Aux>

    );

  }

}

 

export default LoginForm;

